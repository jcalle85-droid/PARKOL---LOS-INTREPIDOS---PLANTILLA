package co.edu.uan.android.parkol.domain

import kotlin.test.Test
import kotlin.test.assertEquals

class FeeCalculatorTest {
    @Test
    fun carro_3h25_cuesta_12000() = assertEquals(12000, FeeCalculator.total(205, 3000))

    @Test
    fun moto_2h20_cuesta_6000() = assertEquals(6000, FeeCalculator.total(140, 2000))

    @Test
    fun minimo_una_hora() = assertEquals(3000, FeeCalculator.total(0, 3000))

    @Test
    fun hora_exacta_no_cobra_fraccion() = assertEquals(3000, FeeCalculator.total(60, 3000))

    @Test
    fun un_minuto_extra_cobra_otra_hora() = assertEquals(6000, FeeCalculator.total(61, 3000))

    @Test
    fun formato_de_duracion() = assertEquals("3 h 25 min", FeeCalculator.formatDuration(205))

    @Test
    fun minutos_nunca_son_negativos() = assertEquals(0L, FeeCalculator.minutesBetween(5_000L, 1_000L))
}
