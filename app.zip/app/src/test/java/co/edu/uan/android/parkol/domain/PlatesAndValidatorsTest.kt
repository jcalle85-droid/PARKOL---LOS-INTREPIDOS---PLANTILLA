package co.edu.uan.android.parkol.domain

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

class PlatesAndValidatorsTest {
    @Test
    fun placa_de_carro_se_normaliza() = assertEquals("ABC123", Plates.normalize(" abc 123 "))

    @Test
    fun placa_de_moto_es_valida() = assertEquals("ABC12D", Plates.normalize("abc12d"))

    @Test
    fun placa_invalida_devuelve_null() {
        assertNull(Plates.normalize("12345"))
        assertNull(Plates.normalize("ABCD12"))
        assertNull(Plates.normalize(""))
    }

    @Test
    fun correo_valido_e_invalido() {
        assertNull(Validators.email("parkol123@gmail.com"))
        assertNotNull(Validators.email("parkol123"))
    }

    @Test
    fun contrasena_minimo_seis_caracteres() {
        assertNull(Validators.password("234JHt"))
        assertNotNull(Validators.password("123"))
    }

    @Test
    fun hash_es_estable_y_distinto_por_contrasena() {
        assertEquals(PasswordHasher.hash("Admin123"), PasswordHasher.hash("Admin123"))
        assertNotEquals(PasswordHasher.hash("Admin123"), PasswordHasher.hash("admin123"))
    }
}
