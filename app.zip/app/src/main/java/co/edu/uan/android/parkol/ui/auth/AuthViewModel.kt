package co.edu.uan.android.parkol.ui.auth

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import co.edu.uan.android.parkol.data.model.OpResult
import co.edu.uan.android.parkol.data.model.User
import co.edu.uan.android.parkol.data.storage.ParkolStore
import co.edu.uan.android.parkol.domain.PasswordHasher
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val store: ParkolStore
) : ViewModel() {

    var currentUser by mutableStateOf<User?>(
        store.loadUsers().firstOrNull { it.email == store.sessionEmail }
    )
        private set

    fun login(email: String, password: String): OpResult {
        val user = store.loadUsers().firstOrNull { it.email.equals(email.trim(), ignoreCase = true) }
        if (user == null || user.passwordHash != PasswordHasher.hash(password)) {
            return OpResult(false, "Correo o contraseña incorrectos")
        }
        startSession(user)
        return OpResult(true, "Bienvenido, ${user.name}")
    }

    fun register(name: String, email: String, password: String): OpResult {
        val users = store.loadUsers()
        if (users.any { it.email.equals(email.trim(), ignoreCase = true) }) {
            return OpResult(false, "Ya existe una cuenta con ese correo")
        }
        val user = User(
            name = name.trim(),
            email = email.trim().lowercase(),
            passwordHash = PasswordHasher.hash(password),
            isAdmin = false
        )
        store.saveUsers(users + user)
        startSession(user)
        return OpResult(true, "Cuenta creada")
    }

    fun logout() {
        store.sessionEmail = null
        currentUser = null
    }

    private fun startSession(user: User) {
        store.sessionEmail = user.email
        currentUser = user
    }
}
