package co.edu.uan.android.parkol.ui.theme

import androidx.compose.ui.graphics.Color

val NavyDeep = Color(0xFF0B1030)
val Navy = Color(0xFF14204A)
val PurpleGlass = Color(0xFF332E7A)
val PurpleCard = Color(0xFF221E5A)
val PurpleLight = Color(0xFF9D96FF)
val InputBg = Color(0xFF2A2560)

val SlotFree = Color(0xFF43A047)
val SlotBusy = Color(0xFFE53935)
val SlotReserved = Color(0xFFFFB300)

val LinkRed = Color(0xFFFF6B6B)
val TextMuted = Color(0xB3FFFFFF)
