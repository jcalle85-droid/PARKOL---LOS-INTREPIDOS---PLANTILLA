package co.edu.uan.android.parkol.domain

/** Placas colombianas: carro ABC123 y moto ABC12D. */
object Plates {
    const val ERROR = "Placa inválida. Ejemplos: ABC123 (carro) o ABC12D (moto)"

    private val PATTERN = Regex("^[A-Z]{3}[0-9]{2}[0-9A-Z]$")

    /** Devuelve la placa en mayúsculas y sin espacios, o null si no es válida. */
    fun normalize(raw: String): String? {
        val plate = raw.trim().uppercase().replace(" ", "")
        return if (PATTERN.matches(plate)) plate else null
    }
}
