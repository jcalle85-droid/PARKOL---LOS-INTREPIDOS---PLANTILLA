package co.edu.uan.android.parkol.data.model

enum class VehicleType(val label: String) {
    CARRO("Carro"),
    MOTO("Moto")
}

enum class SlotStatus { LIBRE, OCUPADO, RESERVADO }

/** Un cupo del parqueadero. [plate] guarda la placa del vehículo (ocupado) o de la reserva. */
data class Slot(
    val number: Int,
    val zone: String,
    val type: VehicleType,
    val status: SlotStatus = SlotStatus.LIBRE,
    val plate: String? = null,
    val entryMillis: Long? = null
)

/** Registro de un vehículo que ya salió y pagó. */
data class ParkingRecord(
    val id: Long,
    val plate: String,
    val type: VehicleType,
    val slot: Int,
    val entryMillis: Long,
    val exitMillis: Long,
    val minutes: Long,
    val total: Int
)

data class Rates(val carPerHour: Int = 3000, val motoPerHour: Int = 2000) {
    fun forType(type: VehicleType): Int =
        if (type == VehicleType.CARRO) carPerHour else motoPerHour
}

data class User(
    val name: String,
    val email: String,
    val passwordHash: String,
    val isAdmin: Boolean
)

/** Resultado de una operación: [ok] indica éxito y [message] se muestra al usuario. */
data class OpResult(val ok: Boolean, val message: String)

/** Cuenta de cobro calculada para un vehículo que está por salir. */
data class Quote(
    val plate: String,
    val type: VehicleType,
    val slot: Int,
    val entryMillis: Long,
    val exitMillis: Long,
    val minutes: Long,
    val total: Int
)

object ParkingLayout {
    const val TOTAL = 50

    /** Zona A: cupos 1-20 (carros) · Zona B: 21-40 (carros) · Zona C: 41-50 (motos). */
    fun defaultSlots(): List<Slot> = (1..TOTAL).map { n ->
        when {
            n <= 20 -> Slot(n, "A", VehicleType.CARRO)
            n <= 40 -> Slot(n, "B", VehicleType.CARRO)
            else -> Slot(n, "C", VehicleType.MOTO)
        }
    }
}
