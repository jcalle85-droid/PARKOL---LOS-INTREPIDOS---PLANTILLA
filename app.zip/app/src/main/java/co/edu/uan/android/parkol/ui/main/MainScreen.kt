package co.edu.uan.android.parkol.ui.main

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalParking
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import co.edu.uan.android.parkol.data.model.User
import co.edu.uan.android.parkol.ui.components.parkolGradient
import co.edu.uan.android.parkol.ui.theme.Navy
import co.edu.uan.android.parkol.ui.theme.PurpleGlass
import co.edu.uan.android.parkol.ui.theme.TextMuted
import kotlinx.coroutines.launch

private data class TabItem(val title: String, val icon: ImageVector)

@Composable
fun MainScreen(
    user: User,
    onLogout: () -> Unit,
    vm: ParkingViewModel = hiltViewModel()
) {
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val notify: (String) -> Unit = { message -> scope.launch { snackbar.showSnackbar(message) } }

    val tabs = remember(user.isAdmin) {
        buildList {
            add(TabItem("Cupos", Icons.Filled.LocalParking))
            add(TabItem("Historial", Icons.Filled.History))
            if (user.isAdmin) add(TabItem("Admin", Icons.Filled.AdminPanelSettings))
        }
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val selected = tab.coerceIn(0, tabs.lastIndex)

    Scaffold(
        modifier = Modifier.parkolGradient(),
        containerColor = Color.Transparent,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar(containerColor = Navy) {
                tabs.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = selected == index,
                        onClick = { tab = index },
                        icon = { Icon(item.icon, contentDescription = item.title) },
                        label = { Text(item.title) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            indicatorColor = PurpleGlass,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                }
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("ParKol", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = if (user.isAdmin) "Administrador · ${user.name}" else user.name,
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }
                IconButton(onClick = onLogout) {
                    Icon(
                        Icons.AutoMirrored.Filled.Logout,
                        contentDescription = "Cerrar sesión",
                        tint = Color.White
                    )
                }
            }

            when (tabs[selected].title) {
                "Cupos" -> SlotsScreen(vm, notify, Modifier.weight(1f))
                "Historial" -> HistoryScreen(vm.records, Modifier.weight(1f))
                else -> AdminScreen(vm, notify, Modifier.weight(1f))
            }
        }
    }
}
