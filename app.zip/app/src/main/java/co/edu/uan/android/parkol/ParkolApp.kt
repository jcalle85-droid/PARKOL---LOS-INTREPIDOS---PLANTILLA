package co.edu.uan.android.parkol

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import co.edu.uan.android.parkol.ui.auth.AuthViewModel
import co.edu.uan.android.parkol.ui.auth.LoginScreen
import co.edu.uan.android.parkol.ui.auth.RegisterScreen
import co.edu.uan.android.parkol.ui.auth.WelcomeScreen
import co.edu.uan.android.parkol.ui.main.MainScreen

private object Routes {
    const val WELCOME = "welcome"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val MAIN = "main"
}

@Composable
fun ParkolApp(auth: AuthViewModel = hiltViewModel()) {
    val nav = rememberNavController()
    val start = if (auth.currentUser != null) Routes.MAIN else Routes.WELCOME

    NavHost(navController = nav, startDestination = start) {
        composable(Routes.WELCOME) {
            WelcomeScreen(
                onLogin = { nav.navigate(Routes.LOGIN) },
                onRegister = { nav.navigate(Routes.REGISTER) }
            )
        }
        composable(Routes.LOGIN) {
            LoginScreen(
                auth = auth,
                onSuccess = { nav.goToMain() },
                onRegister = { nav.navigate(Routes.REGISTER) }
            )
        }
        composable(Routes.REGISTER) {
            RegisterScreen(
                auth = auth,
                onSuccess = { nav.goToMain() },
                onLogin = { nav.navigate(Routes.LOGIN) }
            )
        }
        composable(Routes.MAIN) {
            val user = auth.currentUser ?: return@composable
            MainScreen(
                user = user,
                onLogout = {
                    auth.logout()
                    nav.navigate(Routes.WELCOME) {
                        popUpTo(nav.graph.id) { inclusive = true }
                    }
                }
            )
        }
    }
}

private fun NavHostController.goToMain() {
    navigate("main") {
        popUpTo(graph.id) { inclusive = true }
    }
}
