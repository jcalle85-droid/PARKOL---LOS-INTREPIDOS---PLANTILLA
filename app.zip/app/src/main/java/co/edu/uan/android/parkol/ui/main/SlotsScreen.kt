package co.edu.uan.android.parkol.ui.main

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import co.edu.uan.android.parkol.data.model.OpResult
import co.edu.uan.android.parkol.data.model.Slot
import co.edu.uan.android.parkol.data.model.SlotStatus
import co.edu.uan.android.parkol.data.model.VehicleType
import co.edu.uan.android.parkol.domain.FeeCalculator
import co.edu.uan.android.parkol.domain.Formats
import co.edu.uan.android.parkol.ui.components.PillButton
import co.edu.uan.android.parkol.ui.theme.NavyDeep
import co.edu.uan.android.parkol.ui.theme.PurpleCard
import co.edu.uan.android.parkol.ui.theme.SlotBusy
import co.edu.uan.android.parkol.ui.theme.SlotFree
import co.edu.uan.android.parkol.ui.theme.SlotReserved
import co.edu.uan.android.parkol.ui.theme.TextMuted

@Composable
fun SlotsScreen(vm: ParkingViewModel, notify: (String) -> Unit, modifier: Modifier = Modifier) {
    var showEntry by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SummaryCard("Disponibles", vm.available, SlotFree, Modifier.weight(1f))
            SummaryCard("Ocupados", vm.occupied, SlotBusy, Modifier.weight(1f))
            SummaryCard("Reservados", vm.reserved, SlotReserved, Modifier.weight(1f))
        }

        PillButton("Registrar entrada", { showEntry = true }, Modifier.fillMaxWidth())

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            LegendItem("Disponible", SlotFree)
            LegendItem("Ocupado", SlotBusy)
            LegendItem("Reservado", SlotReserved)
        }

        vm.slots.groupBy { it.zone }.forEach { (zone, zoneSlots) ->
            ZoneCard(zone, zoneSlots) { selected = it.number }
        }

        Text(
            "Toca un cupo para registrar entrada, reservar o cobrar la salida.",
            color = TextMuted,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }

    if (showEntry) {
        EntryDialog(
            onDismiss = { showEntry = false },
            onConfirm = { plate, type -> vm.registerEntry(plate, type) },
            notify = notify
        )
    }

    selected?.let { number ->
        val slot = vm.slots.firstOrNull { it.number == number }
        if (slot != null) {
            SlotDialog(slot, vm, notify) { selected = null }
        }
    }
}

// ---------------------------------------------------------------- Piezas

@Composable
private fun SummaryCard(label: String, count: Int, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PurpleCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = TextMuted, fontSize = 12.sp)
            Text(count.toString(), color = color, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun ZoneCard(zone: String, slots: List<Slot>, onSlot: (Slot) -> Unit) {
    val kind = if (slots.first().type == VehicleType.CARRO) "CARROS" else "MOTOS"
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PurpleCard)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("ZONA $zone — $kind", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            slots.chunked(5).forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { slot ->
                        SlotChip(slot, Modifier.weight(1f)) { onSlot(slot) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SlotChip(slot: Slot, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val background = when (slot.status) {
        SlotStatus.LIBRE -> SlotFree
        SlotStatus.OCUPADO -> SlotBusy
        SlotStatus.RESERVADO -> SlotReserved
    }
    val content = if (slot.status == SlotStatus.RESERVADO) NavyDeep else Color.White
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(Formats.slotNumber(slot.number), color = content, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (slot.plate != null) {
                Text(slot.plate, color = content, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun PlateField(value: String, onChange: (String) -> Unit, error: String?) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6)) },
        label = { Text("Placa (ej. ABC123)") },
        singleLine = true,
        isError = error != null,
        supportingText = if (error != null) {
            { Text(error) }
        } else null,
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
        modifier = Modifier.fillMaxWidth()
    )
}

// ---------------------------------------------------------------- Diálogos

@Composable
private fun EntryDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, VehicleType) -> OpResult,
    notify: (String) -> Unit
) {
    var plate by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(VehicleType.CARRO) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PurpleCard,
        titleContentColor = Color.White,
        textContentColor = Color.White,
        title = { Text("Registrar entrada") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PlateField(plate, { plate = it; error = null }, error)
                Text("Tipo de vehículo", color = TextMuted, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    VehicleType.values().forEach { option ->
                        Row(
                            modifier = Modifier.clickable { type = option },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = type == option,
                                onClick = { type = option },
                                colors = RadioButtonDefaults.colors(selectedColor = Color.White, unselectedColor = TextMuted)
                            )
                            Text(option.label)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val result = onConfirm(plate, type)
                if (result.ok) {
                    notify(result.message)
                    onDismiss()
                } else {
                    error = result.message
                }
            }) { Text("Registrar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun SlotDialog(
    slot: Slot,
    vm: ParkingViewModel,
    notify: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var plate by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val quote = remember(slot) { if (slot.status == SlotStatus.OCUPADO) vm.quote(slot.number) else null }

    fun handle(result: OpResult) {
        if (result.ok) {
            notify(result.message)
            onDismiss()
        } else {
            error = result.message
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PurpleCard,
        titleContentColor = Color.White,
        textContentColor = Color.White,
        title = {
            Text(
                "Cupo ${Formats.slotNumber(slot.number)} · Zona ${slot.zone} (${slot.type.label})",
                fontSize = 18.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (slot.status) {
                    SlotStatus.LIBRE -> {
                        PlateField(plate, { plate = it; error = null }, error)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { handle(vm.enterAtSlot(slot.number, plate)) },
                                modifier = Modifier.weight(1f)
                            ) { Text("Entrada") }
                            OutlinedButton(
                                onClick = { handle(vm.reserve(slot.number, plate)) },
                                modifier = Modifier.weight(1f)
                            ) { Text("Reservar") }
                        }
                    }

                    SlotStatus.RESERVADO -> {
                        Text("Reservado para ${slot.plate}")
                        Button(
                            onClick = { handle(vm.occupyReservation(slot.number)) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Registrar entrada") }
                        OutlinedButton(
                            onClick = { handle(vm.cancelReservation(slot.number)) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Cancelar reserva") }
                    }

                    SlotStatus.OCUPADO -> {
                        if (quote == null) {
                            Text("No se pudo calcular el cobro de este cupo.")
                        } else {
                            Text("Placa: ${quote.plate}", fontWeight = FontWeight.Bold)
                            Text("Entrada: ${Formats.dateTime(quote.entryMillis)}")
                            Text("Tiempo: ${FeeCalculator.formatDuration(quote.minutes)}")
                            Text(
                                "Tarifa: ${Formats.money(vm.rates.forType(quote.type))} por hora o fracción",
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                            Text(
                                "Total: ${Formats.money(quote.total)}",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Button(
                                onClick = { handle(vm.registerPayment(slot.number)) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Registrar salida y pago") }
                        }
                    }
                }
                if (slot.status != SlotStatus.LIBRE && error != null) {
                    Text(error ?: "", color = MaterialErrorColor, fontSize = 13.sp)
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

private val MaterialErrorColor = Color(0xFFFF6B6B)
