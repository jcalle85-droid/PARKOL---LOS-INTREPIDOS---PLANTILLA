package co.edu.uan.android.parkol.ui.auth

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import co.edu.uan.android.parkol.domain.Validators
import co.edu.uan.android.parkol.ui.components.GlassTextField
import co.edu.uan.android.parkol.ui.components.LogoCard
import co.edu.uan.android.parkol.ui.components.PhotoBackground
import co.edu.uan.android.parkol.ui.components.PillButton
import co.edu.uan.android.parkol.ui.theme.LinkRed
import co.edu.uan.android.parkol.ui.theme.Navy
import co.edu.uan.android.parkol.ui.theme.TextMuted

// ---------------------------------------------------------------- Bienvenida

@Composable
fun WelcomeScreen(onLogin: () -> Unit, onRegister: () -> Unit) {
    PhotoBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(32.dp))
            LogoCard(size = 190.dp)
            Spacer(Modifier.weight(1f))
            PillButton("INICIAR SESIÓN", onLogin, Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onRegister) {
                Text("REGÍSTRAME", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ---------------------------------------------------------------- Login

@Composable
fun LoginScreen(auth: AuthViewModel, onSuccess: () -> Unit, onRegister: () -> Unit) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }

    fun comingSoon() = Toast.makeText(context, "Próximamente", Toast.LENGTH_SHORT).show()

    fun submit() {
        formError = null
        emailError = Validators.email(email)
        passwordError = if (password.isEmpty()) "Ingresa tu contraseña" else null
        if (emailError == null && passwordError == null) {
            val result = auth.login(email, password)
            if (result.ok) onSuccess() else formError = result.message
        }
    }

    AuthLayout(logoSize = 160.dp) {
        Text(
            "INICIAR SESIÓN",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        FieldLabel("Correo electrónico:")
        GlassTextField(
            value = email,
            onValueChange = { email = it; emailError = null },
            placeholder = "ejemplo: parkol123@gmail.com",
            icon = Icons.Filled.Email,
            error = emailError,
            keyboardType = KeyboardType.Email
        )
        FieldLabel("Contraseña:")
        GlassTextField(
            value = password,
            onValueChange = { password = it; passwordError = null },
            placeholder = "ejemplo: 234JHtml",
            icon = Icons.Filled.Lock,
            error = passwordError,
            isPassword = true,
            showPassword = showPassword,
            keyboardType = KeyboardType.Password,
            imeAction = ImeAction.Done,
            onDone = { submit() }
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = showPassword,
                onCheckedChange = { showPassword = it },
                colors = CheckboxDefaults.colors(
                    checkedColor = Color.White,
                    uncheckedColor = Color.White,
                    checkmarkColor = Navy
                )
            )
            Text("Mostrar contraseña", color = Color.White, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text(
                "¿Olvidaste la contraseña?",
                color = LinkRed,
                fontSize = 12.sp,
                modifier = Modifier
                    .clickable { comingSoon() }
                    .padding(6.dp)
            )
        }
        formError?.let {
            Text(it, color = LinkRed, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(8.dp))
        PillButton("INICIAR SESIÓN", { submit() }, Modifier.align(Alignment.CenterHorizontally).width(240.dp))

        Spacer(Modifier.height(20.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Line()
            Text("  o continúa con  ", color = Color.White, fontSize = 14.sp)
            Line()
        }
        Spacer(Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)
        ) {
            SocialButton("GOOGLE", "G", Color.White, Color(0xFF4285F4)) { comingSoon() }
            SocialButton("FACEBOOK", "f", Color(0xFF1877F2), Color.White) { comingSoon() }
        }
        TextButton(onClick = onRegister, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("¿No tienes cuenta? Regístrate", color = Color.White, fontSize = 13.sp)
        }
    }
}

// ---------------------------------------------------------------- Registro

@Composable
fun RegisterScreen(auth: AuthViewModel, onSuccess: () -> Unit, onLogin: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var confirmError by remember { mutableStateOf<String?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }

    fun submit() {
        formError = null
        nameError = Validators.name(name)
        emailError = Validators.email(email)
        passwordError = Validators.password(password)
        confirmError = if (confirm != password) "Las contraseñas no coinciden" else null
        if (listOf(nameError, emailError, passwordError, confirmError).all { it == null }) {
            val result = auth.register(name, email, password)
            if (result.ok) onSuccess() else formError = result.message
        }
    }

    AuthLayout(logoSize = 140.dp) {
        Text(
            "CREAR CUENTA",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        FieldLabel("Nombre:")
        GlassTextField(
            value = name,
            onValueChange = { name = it; nameError = null },
            placeholder = "ejemplo: Camila Aguirre",
            icon = Icons.Filled.Person,
            error = nameError
        )
        FieldLabel("Correo electrónico:")
        GlassTextField(
            value = email,
            onValueChange = { email = it; emailError = null },
            placeholder = "ejemplo: parkol123@gmail.com",
            icon = Icons.Filled.Email,
            error = emailError,
            keyboardType = KeyboardType.Email
        )
        FieldLabel("Contraseña:")
        GlassTextField(
            value = password,
            onValueChange = { password = it; passwordError = null },
            placeholder = "mínimo 6 caracteres",
            icon = Icons.Filled.Lock,
            error = passwordError,
            isPassword = true,
            showPassword = showPassword,
            keyboardType = KeyboardType.Password
        )
        FieldLabel("Confirmar contraseña:")
        GlassTextField(
            value = confirm,
            onValueChange = { confirm = it; confirmError = null },
            placeholder = "repite tu contraseña",
            icon = Icons.Filled.Lock,
            error = confirmError,
            isPassword = true,
            showPassword = showPassword,
            keyboardType = KeyboardType.Password,
            imeAction = ImeAction.Done,
            onDone = { submit() }
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = showPassword,
                onCheckedChange = { showPassword = it },
                colors = CheckboxDefaults.colors(
                    checkedColor = Color.White,
                    uncheckedColor = Color.White,
                    checkmarkColor = Navy
                )
            )
            Text("Mostrar contraseña", color = Color.White, fontSize = 12.sp)
        }
        formError?.let {
            Text(it, color = LinkRed, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(8.dp))
        PillButton("REGISTRARME", { submit() }, Modifier.align(Alignment.CenterHorizontally).width(240.dp))
        TextButton(onClick = onLogin, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("¿Ya tienes cuenta? Inicia sesión", color = Color.White, fontSize = 13.sp)
        }
    }
}

// ---------------------------------------------------------------- Piezas compartidas

@Composable
private fun AuthLayout(logoSize: Dp, content: @Composable ColumnScope.() -> Unit) {
    PhotoBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LogoCard(size = logoSize)
            Spacer(Modifier.height(24.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(40.dp))
                    .background(Color(0x99332E7A))
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                content = content
            )
        }
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text,
        color = Color.White,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 10.dp)
    )
}

@Composable
private fun Line() {
    Box(
        Modifier
            .width(48.dp)
            .height(1.dp)
            .background(Color(0x99FFFFFF))
    )
}

@Composable
private fun SocialButton(
    label: String,
    letter: String,
    badgeColor: Color,
    letterColor: Color,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color(0x66FFFFFF))
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(badgeColor),
            contentAlignment = Alignment.Center
        ) {
            Text(letter, color = letterColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text(label, color = TextMuted.copy(alpha = 1f), fontSize = 13.sp)
    }
}
