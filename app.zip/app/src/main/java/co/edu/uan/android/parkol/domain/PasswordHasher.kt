package co.edu.uan.android.parkol.domain

import java.security.MessageDigest

/** Hash SHA-256 para no guardar contraseñas en texto plano (suficiente para la v0.1.0 local). */
object PasswordHasher {
    fun hash(password: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(password.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
}
