package co.edu.uan.android.parkol

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ParkolApplication : Application()
