package co.edu.uan.android.parkol.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ParkolColorScheme = darkColorScheme(
    primary = PurpleLight,
    onPrimary = NavyDeep,
    secondary = Navy,
    onSecondary = Color.White,
    tertiary = SlotReserved,
    background = NavyDeep,
    onBackground = Color.White,
    surface = PurpleCard,
    onSurface = Color.White,
    surfaceVariant = InputBg,
    onSurfaceVariant = TextMuted,
    error = LinkRed,
    outline = Color(0x66FFFFFF)
)

/** ParKol usa siempre el tema oscuro para mantener la identidad visual del mockup. */
@Composable
fun ParkolTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ParkolColorScheme,
        typography = Typography,
        content = content
    )
}
