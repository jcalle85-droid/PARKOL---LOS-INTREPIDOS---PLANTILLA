package co.edu.uan.android.parkol.ui.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import co.edu.uan.android.parkol.domain.Formats
import co.edu.uan.android.parkol.ui.theme.LinkRed
import co.edu.uan.android.parkol.ui.theme.PurpleCard
import co.edu.uan.android.parkol.ui.theme.TextMuted

@Composable
fun AdminScreen(vm: ParkingViewModel, notify: (String) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }
            .getOrNull() ?: "0.1.0"
    }
    var car by remember(vm.rates) { mutableStateOf(vm.rates.carPerHour.toString()) }
    var moto by remember(vm.rates) { mutableStateOf(vm.rates.motoPerHour.toString()) }
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Atendidos", vm.records.size.toString(), Modifier.weight(1f))
            StatCard("Ocupación", "${vm.occupancyPercent}%", Modifier.weight(1f))
        }
        StatCard("Ingresos totales", Formats.money(vm.totalRevenue), Modifier.fillMaxWidth())

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = PurpleCard)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Tarifas por hora o fracción", color = Color.White, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = car,
                    onValueChange = { car = it.filter { c -> c.isDigit() }.take(7) },
                    label = { Text("Carro (COP)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = moto,
                    onValueChange = { moto = it.filter { c -> c.isDigit() }.take(7) },
                    label = { Text("Moto (COP)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { notify(vm.updateRates(car, moto).message) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Guardar tarifas") }
            }
        }

        OutlinedButton(
            onClick = { confirmReset = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Restablecer datos del parqueadero", color = LinkRed) }

        Text(
            "ParKol v$version",
            color = TextMuted,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = PurpleCard,
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text("¿Restablecer datos?") },
            text = { Text("Se liberarán los 50 cupos y se borrará el historial. Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = {
                    notify(vm.resetAll().message)
                    confirmReset = false
                }) { Text("Restablecer", color = LinkRed) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PurpleCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = TextMuted, fontSize = 13.sp)
            Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}
