package co.edu.uan.android.parkol.ui.main

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import co.edu.uan.android.parkol.data.model.ParkingRecord
import co.edu.uan.android.parkol.domain.FeeCalculator
import co.edu.uan.android.parkol.domain.Formats
import co.edu.uan.android.parkol.ui.theme.PurpleCard
import co.edu.uan.android.parkol.ui.theme.SlotFree
import co.edu.uan.android.parkol.ui.theme.TextMuted

@Composable
fun HistoryScreen(records: List<ParkingRecord>, modifier: Modifier = Modifier) {
    if (records.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                "Aún no hay vehículos en el historial.\nAparecerán aquí cuando registres una salida.",
                color = TextMuted,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(32.dp)
            )
        }
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(records.asReversed(), key = { it.id }) { record ->
            RecordCard(record)
        }
    }
}

@Composable
private fun RecordCard(record: ParkingRecord) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PurpleCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    record.plate,
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "Pagado",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(SlotFree)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
            Text("${record.type.label} · Cupo ${Formats.slotNumber(record.slot)}", color = TextMuted, fontSize = 13.sp)
            Text("Entrada: ${Formats.dateTime(record.entryMillis)}", color = Color.White, fontSize = 14.sp)
            Text("Salida: ${Formats.dateTime(record.exitMillis)}", color = Color.White, fontSize = 14.sp)
            Text("Tiempo: ${FeeCalculator.formatDuration(record.minutes)}", color = Color.White, fontSize = 14.sp)
            Text(
                "Total: ${Formats.money(record.total)}",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
