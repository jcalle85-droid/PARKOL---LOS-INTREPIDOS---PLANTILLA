package co.edu.uan.android.parkol.domain

object Validators {
    private val EMAIL = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    fun email(value: String): String? =
        if (EMAIL.matches(value.trim())) null else "Ingresa un correo válido"

    fun password(value: String): String? =
        if (value.length >= 6) null else "Mínimo 6 caracteres"

    fun name(value: String): String? =
        if (value.trim().length >= 2) null else "Ingresa tu nombre"
}
