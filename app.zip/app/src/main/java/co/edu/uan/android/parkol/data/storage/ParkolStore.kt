package co.edu.uan.android.parkol.data.storage

import android.content.Context
import co.edu.uan.android.parkol.data.model.ParkingLayout
import co.edu.uan.android.parkol.data.model.ParkingRecord
import co.edu.uan.android.parkol.data.model.Rates
import co.edu.uan.android.parkol.data.model.Slot
import co.edu.uan.android.parkol.data.model.SlotStatus
import co.edu.uan.android.parkol.data.model.User
import co.edu.uan.android.parkol.data.model.VehicleType
import co.edu.uan.android.parkol.domain.PasswordHasher
import dagger.hilt.android.qualifiers.ApplicationContext
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Guarda todo en SharedPreferences (JSON) para que los datos sobrevivan al cerrar la app.
 * En una versión futura se puede cambiar por Room sin tocar las pantallas.
 */
@Singleton
class ParkolStore @Inject constructor(@ApplicationContext context: Context) {

    private val prefs = context.getSharedPreferences("parkol_data", Context.MODE_PRIVATE)

    // ---------- Cupos ----------
    fun loadSlots(): List<Slot> = readList("slots", ParkingLayout.defaultSlots()) { it.toSlot() }

    fun saveSlots(slots: List<Slot>) = writeList("slots", slots.map { it.toJson() })

    // ---------- Historial ----------
    fun loadRecords(): List<ParkingRecord> = readList("records", emptyList()) { it.toRecord() }

    fun saveRecords(records: List<ParkingRecord>) = writeList("records", records.map { it.toJson() })

    // ---------- Tarifas ----------
    fun loadRates(): Rates = Rates(
        carPerHour = prefs.getInt("rate_car", 3000),
        motoPerHour = prefs.getInt("rate_moto", 2000)
    )

    fun saveRates(rates: Rates) {
        prefs.edit()
            .putInt("rate_car", rates.carPerHour)
            .putInt("rate_moto", rates.motoPerHour)
            .apply()
    }

    // ---------- Usuarios y sesión ----------
    /** Si aún no hay usuarios guardados, devuelve solo el administrador de demostración. */
    fun loadUsers(): List<User> = readList("users", listOf(demoAdmin())) { it.toUser() }

    fun saveUsers(users: List<User>) = writeList("users", users.map { it.toJson() })

    var sessionEmail: String?
        get() = prefs.getString("session_email", null)
        set(value) {
            prefs.edit().putString("session_email", value).apply()
        }

    // ---------- Utilidades ----------
    private fun <T> readList(key: String, default: List<T>, parse: (JSONObject) -> T): List<T> {
        val raw = prefs.getString(key, null) ?: return default
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { parse(array.getJSONObject(it)) }
        } catch (e: Exception) {
            default
        }
    }

    private fun writeList(key: String, items: List<JSONObject>) {
        val array = JSONArray()
        items.forEach { array.put(it) }
        prefs.edit().putString(key, array.toString()).apply()
    }

    private fun demoAdmin() = User(
        name = "Administrador",
        email = "admin@parkol.com",
        passwordHash = PasswordHasher.hash("Admin123"),
        isAdmin = true
    )

    private fun JSONObject.stringOrNull(name: String): String? =
        if (isNull(name)) null else getString(name)

    private fun JSONObject.longOrNull(name: String): Long? =
        if (isNull(name)) null else getLong(name)

    private fun Slot.toJson() = JSONObject()
        .put("number", number)
        .put("zone", zone)
        .put("type", type.name)
        .put("status", status.name)
        .put("plate", plate ?: JSONObject.NULL)
        .put("entry", entryMillis ?: JSONObject.NULL)

    private fun JSONObject.toSlot() = Slot(
        number = getInt("number"),
        zone = getString("zone"),
        type = VehicleType.valueOf(getString("type")),
        status = SlotStatus.valueOf(getString("status")),
        plate = stringOrNull("plate"),
        entryMillis = longOrNull("entry")
    )

    private fun ParkingRecord.toJson() = JSONObject()
        .put("id", id)
        .put("plate", plate)
        .put("type", type.name)
        .put("slot", slot)
        .put("entry", entryMillis)
        .put("exit", exitMillis)
        .put("minutes", minutes)
        .put("total", total)

    private fun JSONObject.toRecord() = ParkingRecord(
        id = getLong("id"),
        plate = getString("plate"),
        type = VehicleType.valueOf(getString("type")),
        slot = getInt("slot"),
        entryMillis = getLong("entry"),
        exitMillis = getLong("exit"),
        minutes = getLong("minutes"),
        total = getInt("total")
    )

    private fun User.toJson() = JSONObject()
        .put("name", name)
        .put("email", email)
        .put("hash", passwordHash)
        .put("admin", isAdmin)

    private fun JSONObject.toUser() = User(
        name = getString("name"),
        email = getString("email"),
        passwordHash = getString("hash"),
        isAdmin = getBoolean("admin")
    )
}
