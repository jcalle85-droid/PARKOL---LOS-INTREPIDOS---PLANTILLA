package co.edu.uan.android.parkol.domain

/** Reglas de cobro: se cobra por hora o fracción, con un mínimo de una hora. */
object FeeCalculator {

    fun minutesBetween(entryMillis: Long, exitMillis: Long): Long =
        maxOf(0L, (exitMillis - entryMillis) / 60_000L)

    fun billableHours(minutes: Long): Long =
        if (minutes <= 0L) 1L else (minutes + 59L) / 60L

    fun total(minutes: Long, perHour: Int): Int =
        (billableHours(minutes) * perHour).toInt()

    fun formatDuration(minutes: Long): String = "${minutes / 60} h ${minutes % 60} min"
}
