package co.edu.uan.android.parkol.ui.main

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import co.edu.uan.android.parkol.data.model.OpResult
import co.edu.uan.android.parkol.data.model.ParkingLayout
import co.edu.uan.android.parkol.data.model.ParkingRecord
import co.edu.uan.android.parkol.data.model.Quote
import co.edu.uan.android.parkol.data.model.Rates
import co.edu.uan.android.parkol.data.model.Slot
import co.edu.uan.android.parkol.data.model.SlotStatus
import co.edu.uan.android.parkol.data.model.VehicleType
import co.edu.uan.android.parkol.data.storage.ParkolStore
import co.edu.uan.android.parkol.domain.FeeCalculator
import co.edu.uan.android.parkol.domain.Formats
import co.edu.uan.android.parkol.domain.Plates
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class ParkingViewModel @Inject constructor(
    private val store: ParkolStore
) : ViewModel() {

    var slots by mutableStateOf(store.loadSlots())
        private set

    var records by mutableStateOf(store.loadRecords())
        private set

    var rates by mutableStateOf(store.loadRates())
        private set

    // ---------- Estadísticas ----------
    val available: Int get() = slots.count { it.status == SlotStatus.LIBRE }
    val occupied: Int get() = slots.count { it.status == SlotStatus.OCUPADO }
    val reserved: Int get() = slots.count { it.status == SlotStatus.RESERVADO }
    val totalRevenue: Int get() = records.sumOf { it.total }
    val occupancyPercent: Int get() = occupied * 100 / slots.size.coerceAtLeast(1)

    // ---------- Entradas ----------

    /** Entrada rápida: asigna automáticamente el primer cupo libre del tipo de vehículo. */
    fun registerEntry(rawPlate: String, type: VehicleType): OpResult {
        val plate = Plates.normalize(rawPlate) ?: return fail(Plates.ERROR)
        if (isInside(plate)) return fail("El vehículo $plate ya está dentro del parqueadero")

        val reservation = slots.firstOrNull { it.status == SlotStatus.RESERVADO && it.plate == plate }
        if (reservation != null) {
            if (reservation.type != type) {
                return fail("La reserva de $plate es para ${reservation.type.label.lowercase()}")
            }
            return occupy(reservation.number, plate)
        }

        val free = slots.firstOrNull { it.status == SlotStatus.LIBRE && it.type == type }
            ?: return fail("No hay cupos libres para ${type.label.lowercase()}")
        return occupy(free.number, plate)
    }

    /** Entrada en un cupo elegido por el usuario. */
    fun enterAtSlot(number: Int, rawPlate: String): OpResult {
        val slot = slots.firstOrNull { it.number == number && it.status == SlotStatus.LIBRE }
            ?: return fail("El cupo ya no está libre")
        val plate = Plates.normalize(rawPlate) ?: return fail(Plates.ERROR)
        if (isInside(plate)) return fail("El vehículo $plate ya está dentro del parqueadero")
        if (hasReservation(plate)) return fail("$plate tiene una reserva en otro cupo")
        return occupy(slot.number, plate)
    }

    // ---------- Reservas ----------

    fun reserve(number: Int, rawPlate: String): OpResult {
        val slot = slots.firstOrNull { it.number == number && it.status == SlotStatus.LIBRE }
            ?: return fail("El cupo ya no está libre")
        val plate = Plates.normalize(rawPlate) ?: return fail(Plates.ERROR)
        if (isInside(plate)) return fail("El vehículo $plate ya está dentro del parqueadero")
        if (hasReservation(plate)) return fail("$plate ya tiene una reserva")
        replaceSlot(slot.number) { it.copy(status = SlotStatus.RESERVADO, plate = plate, entryMillis = null) }
        return OpResult(true, "Cupo ${Formats.slotNumber(number)} reservado para $plate")
    }

    fun occupyReservation(number: Int): OpResult {
        val slot = slots.firstOrNull { it.number == number && it.status == SlotStatus.RESERVADO }
            ?: return fail("Ese cupo no está reservado")
        val plate = slot.plate ?: return fail("La reserva no tiene placa")
        return occupy(number, plate)
    }

    fun cancelReservation(number: Int): OpResult {
        val slot = slots.firstOrNull { it.number == number && it.status == SlotStatus.RESERVADO }
            ?: return fail("Ese cupo no está reservado")
        replaceSlot(number) { it.copy(status = SlotStatus.LIBRE, plate = null, entryMillis = null) }
        return OpResult(true, "Reserva de ${slot.plate} cancelada")
    }

    // ---------- Salida y pago ----------

    /** Calcula el tiempo y el valor a pagar sin modificar nada. */
    fun quote(number: Int, now: Long = System.currentTimeMillis()): Quote? {
        val slot = slots.firstOrNull { it.number == number && it.status == SlotStatus.OCUPADO } ?: return null
        val entry = slot.entryMillis ?: return null
        val plate = slot.plate ?: return null
        val minutes = FeeCalculator.minutesBetween(entry, now)
        return Quote(
            plate = plate,
            type = slot.type,
            slot = slot.number,
            entryMillis = entry,
            exitMillis = now,
            minutes = minutes,
            total = FeeCalculator.total(minutes, rates.forType(slot.type))
        )
    }

    /** Registra el pago, guarda el historial y libera el cupo. */
    fun registerPayment(number: Int): OpResult {
        val bill = quote(number) ?: return fail("Ese cupo no tiene un vehículo")
        val record = ParkingRecord(
            id = (records.maxOfOrNull { it.id } ?: 0L) + 1L,
            plate = bill.plate,
            type = bill.type,
            slot = bill.slot,
            entryMillis = bill.entryMillis,
            exitMillis = bill.exitMillis,
            minutes = bill.minutes,
            total = bill.total
        )
        records = records + record
        store.saveRecords(records)
        replaceSlot(number) { it.copy(status = SlotStatus.LIBRE, plate = null, entryMillis = null) }
        return OpResult(true, "Pago registrado: ${bill.plate} · ${Formats.money(bill.total)}")
    }

    // ---------- Administración ----------

    fun updateRates(carText: String, motoText: String): OpResult {
        val car = carText.trim().toIntOrNull()
        val moto = motoText.trim().toIntOrNull()
        if (car == null || moto == null || car <= 0 || moto <= 0) {
            return fail("Ingresa tarifas válidas (mayores a 0)")
        }
        rates = Rates(carPerHour = car, motoPerHour = moto)
        store.saveRates(rates)
        return OpResult(true, "Tarifas actualizadas")
    }

    fun resetAll(): OpResult {
        slots = ParkingLayout.defaultSlots()
        records = emptyList()
        store.saveSlots(slots)
        store.saveRecords(records)
        return OpResult(true, "Datos del parqueadero restablecidos")
    }

    // ---------- Internos ----------

    private fun fail(message: String) = OpResult(false, message)

    private fun isInside(plate: String) =
        slots.any { it.status == SlotStatus.OCUPADO && it.plate == plate }

    private fun hasReservation(plate: String) =
        slots.any { it.status == SlotStatus.RESERVADO && it.plate == plate }

    private fun occupy(number: Int, plate: String): OpResult {
        replaceSlot(number) {
            it.copy(status = SlotStatus.OCUPADO, plate = plate, entryMillis = System.currentTimeMillis())
        }
        return OpResult(true, "Entrada registrada: $plate en el cupo ${Formats.slotNumber(number)}")
    }

    private fun replaceSlot(number: Int, transform: (Slot) -> Slot) {
        slots = slots.map { if (it.number == number) transform(it) else it }
        store.saveSlots(slots)
    }
}
