package co.edu.uan.android.parkol.domain

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Formats {
    private val locale = Locale("es", "CO")

    fun money(value: Int): String = "$" + NumberFormat.getIntegerInstance(locale).format(value)

    fun dateTime(millis: Long): String =
        SimpleDateFormat("dd/MM/yyyy hh:mm a", locale).format(Date(millis))

    fun slotNumber(number: Int): String = "%02d".format(number)
}
